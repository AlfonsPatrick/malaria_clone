# Malaria-Detection-ML

This is our source code for a web-based malaria classification and detection. Feel free to use and modify 

## Tools used in this project:
- Flask for back-end development
- HTML and CSS for front-end development
- MongoDB for database storing
- MobileNetV2 for image classification

